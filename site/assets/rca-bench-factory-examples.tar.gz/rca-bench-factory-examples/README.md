# rca-bench-factory examples

A copy-and-run copy of the `order-prod` example: the same telemetry, drafts and
rules that every command in the documentation is executed against.

## What is inside

```
README.md
run.sh
MANIFEST.json
examples/order-prod/bundle.json
examples/order-prod/draft.json
examples/order-prod/metrics.csv
examples/order-prod/proposal-draft.json
examples/order-prod/records.json
examples/order-prod/rules.json
```

## Prerequisites

The commands below assume `rca-bench` is on your `PATH`:

```bash
npm install -g @rca-bench-factory/cli
```

Working from a clone instead? Use the built entrypoint directly:
`node /path/to/rca-bench-factory/packages/cli/dist/main.js <command> ...`

## The eight steps

Run them in order, or run all of them with `sh run.sh`.

### 1. Ingest the raw telemetry

The source carries no UTC offset and no service column, so both are declared here rather than guessed. Every ingested signal keeps its raw value alongside the normalised one.

```bash
rca-bench source --path examples/order-prod/metrics.csv --signal-kind metric --assume-offset-minutes 480
```

### 2. Normalise a non-standard column layout

Time, unit and categorical mapping rules are data, not code: the same rules file replays against the next export of the same system.

```bash
rca-bench transform --input examples/order-prod/records.json --rules examples/order-prod/rules.json
```

### 3. Assemble the case

The draft omits the fault category on purpose; the assembler infers `resource` and records the inference. `examples/order-prod/bundle.json` is this exact output, pre-built so the next steps run without step 3.

```bash
rca-bench case --input examples/order-prod/draft.json --output ./bundle.json
```

### 4. Run the quality gates

G1-G5 decide whether the case is allowed to exist. A gate failure here is the cheapest defect you will ever find.

```bash
rca-bench gate --input examples/order-prod/bundle.json --target rca100
```

### 5. Export a target contract

One case, one target contract. Swap the target for any of the nine listed below; the IR does not change.

```bash
rca-bench export --target rca100 --input examples/order-prod/bundle.json --out-dir ./out
```

### 6. Verify the export

Structure checks plus Golden-Master checksum anchors. Exit code 1 means the dataset is not submittable - wire this into CI.

```bash
rca-bench score --target rca100 --dir ./out
```

### 7. Render the evidence report

A single self-contained HTML page: coverage, entity graph, gates and score. This is what a human reviewer actually reads.

```bash
rca-bench report --input examples/order-prod/bundle.json --target rca100 --title "order-prod demo" --output report.html
```

### 8. Propose an evolution

A rule change becomes a reviewable proposal with a regression estimate, and nothing reaches the benchmark until a human approves it.

```bash
rca-bench evolve propose --input examples/order-prod/proposal-draft.json
```

## All nine score targets

One IR bundle, nine contracts. Export any of them from the same `bundle.json`.

| Target | Export | Verify |
| --- | --- | --- |
| `openrca-1.0` | `rca-bench export --target openrca-1.0 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target openrca-1.0 --dir ./out` |
| `openrca-2.0` | `rca-bench export --target openrca-2.0 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target openrca-2.0 --dir ./out` |
| `rcaeval-re1` | `rca-bench export --target rcaeval --suite RE1 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target rcaeval-re1 --dir ./out` |
| `rcaeval-re2` | `rca-bench export --target rcaeval --suite RE2 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target rcaeval-re2 --dir ./out` |
| `rcaeval-re3` | `rca-bench export --target rcaeval --suite RE3 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target rcaeval-re3 --dir ./out` |
| `rca100` | `rca-bench export --target rca100 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target rca100 --dir ./out` |
| `aiops2025` | `rca-bench export --target aiops2025 --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target aiops2025 --dir ./out` |
| `cloud-opsbench` | `rca-bench export --target cloud-opsbench --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target cloud-opsbench --dir ./out` |
| `itbench` | `rca-bench export --target itbench --input examples/order-prod/bundle.json --out-dir ./out` | `rca-bench score --target itbench --dir ./out` |

## Verifying what you downloaded

Every content file is listed in `MANIFEST.json` with its byte length and
SHA-256. The manifest does not list itself -- it cannot carry its own hash -- so
the check below covers the listed files and then confirms that no other file
slipped in.

Run it from the directory **containing** the extracted pack root, not from inside
it: the manifest's paths are relative to where you unpacked the archive, so
`rca-bench-factory-examples/README.md` resolves from there and from nowhere else.

```bash
node -e 'const fs=require("fs"),c=require("crypto");
  const root="rca-bench-factory-examples",m=require("./"+root+"/MANIFEST.json");
  for (const e of m.entries) {
    const b=fs.readFileSync(e.path);
    if (b.length!==e.bytes||c.createHash("sha256").update(b).digest("hex")!==e.sha256) throw new Error("mismatch: "+e.path);
  }
  const listed=new Set([...m.entries.map(e=>e.path),root+"/MANIFEST.json"]);
  const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(x=>x.isDirectory()?walk(d+"/"+x.name):[d+"/"+x.name]);
  const present=walk(root).map(p=>p);
  const unlisted=present.filter(p=>!listed.has(p));
  if (unlisted.length) throw new Error("unlisted file: "+unlisted.join(", "));
  console.log(present.length+" files verified ("+m.fileCount+" listed, plus the manifest)");'
```

The count it prints is the number of files actually in the tree, so it can be
checked against what you extracted rather than taken on trust.

The archive itself is reproducible: rebuilding it from the same inputs produces
byte-identical output, because every tar field that could carry a timestamp or a
user id is pinned to zero.

## Regenerating this pack

```bash
pnpm examples:bundle   # rebuild site/assets/rca-bench-factory-examples.tar.gz
```

Generated by `packages/core/src/pack/example.ts`. Do not edit by hand.
